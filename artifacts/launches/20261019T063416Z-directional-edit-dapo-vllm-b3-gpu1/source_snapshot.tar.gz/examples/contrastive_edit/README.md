# Minimal loop review examples

System files are exact exports of current prompts. Both request files are labeled plain text
rendered by the production function. The proposer receives task/reward evidence; the refiner
additionally receives parent mean logprob and each trajectory's mean-logprob change. No sequence
values are shown in either input. Raw measurements and internal selection still retain sequence sums.
The refiner's favorable/unfavorable feedback is one of two predefined sentences selected from the
computed verification boolean. Semantic causes are inferred by the refiner, not by that template.
Response text and likelihood values are synthetic illustrations, not Qwen research outputs.
The -0.42/-0.31 and +0.18/+0.24 numbers reproduce the user's illustrative example.
