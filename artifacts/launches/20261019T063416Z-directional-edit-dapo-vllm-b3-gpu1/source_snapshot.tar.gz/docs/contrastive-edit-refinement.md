# Minimal likelihood-based prompt update

2026-10-19 사용자 요청으로 이전 복잡한 편집 pipeline을 교체했다. 구현/CPU 테스트와 dry-run만 수행하며
새 GPU 연구 실행은 하지 않는다. 이전 run `20261019T012552Z-contrastive-edit-dapo-pilot-gpu1`의 자료와
source snapshot은 보존한다. GEPA/TextGrad 및 숫자 scorer/backend는 별도 경로로 유지한다.

## 남기는 순서

```text
P + train minibatch -> rollout/reward
  -> proposer가 완성된 instruction C 제안
  -> 동일한 응답 IDs를 P/C 아래에서 측정
  -> refiner가 측정치를 보고 완성된 instruction R 제안
  -> 같은 응답 IDs를 P/R 아래에서 측정
  -> C/R 중 검증된 개선을 반영, 없으면 P 유지
  -> 다음 minibatch
```

각 minibatch에 proposer 1회, refiner 1회만 호출한다. 성공만/실패만/둘 다 있는 경우 모두 진행한다.
새 부모가 결정되면 다음 minibatch에서 새 rollout을 생성한다. Step 내에서는 response IDs와 reward를 바꾸지 않는다.

## Proposer

실패 rollout에서 무엇이 잘못됐는지 진단해 재발을 막는 instruction을 제안한다.
성공 rollout에서는 재현할 행동을 찾아 instruction으로 일반화한다.
입력은 JSON이 아니라 Current prompt P, 고정 출력 규칙, Example x와 gold, Successful/Failed trajectory
전문과 reward를 순서대로 풀어 쓴 텍스트다. Proposer에는 logprob를 주지 않는다.
Gold는 optimizer에만 주고 task 모델에는 주지 않는다. Proposer에는 likelihood 숫자를 주지 않는다.
출력은 완성된 instruction 문자열 하나다. 별도 진단/hypothesis 출력, JSON schema, patch는 없다.

## 측정과 Refiner

Scorer가 full-vocabulary T=1로 원래 response IDs 전체의 sequence logprob를 계산한다.
Thinking과 실제 sampled EOS를 포함한다. `delta_i = L_candidate(y_i)-L_parent(y_i)`.

Refiner 입력은 JSON이 아닌 labeled text다. Current prompt P, Example x와 optimizer용 gold,
Successful/Failed trajectory 전문·reward·부모 아래 mean logprob, Candidate edit P',
응답별 mean logprob 변화, 방향 검사 결과 순으로 보여준다. Sequence 값은 LLM 입력에 넣지 않는다.
관측된 불리한 likelihood 이동을 일으켰을 수 있는 편집의 의미 요소를 추론하고 그 이동을 뒤집는 수정을 요청한다.
수치만 보지 않고 원래/후보 instruction과 실제 응답 내용도 함께 사용한다. 유리했던 방향은 보존한다.
이는 refiner 한 번의 reasoning 안에서 수행하며 별도 hypothesis 출력/탐색 단계는 없다.
LLM에 보여주는 수치는 mean뿐이며, 내부 sequence 기준 검증/점수 및 raw 기록은 바꾸지 않았다.
하단 판정 feedback은 predefined 두 문장이다. 검증된 경우 desired directions 문장,
그 외 undesirable 문장을 `evaluation["verified"]`로 선택한다. 이는 정해진 부호 검사의 문장화이며
편집의 의미적 원인을 계산한 결과가 아니다. 의미 요소의 원인 추론과 새 instruction은 Refiner가 생성한다.
System에 있는 '실패를 성공보다 더 강화하는 편집은 바람직하지 않다'도 고정 지시이지 사례별로 생성한 설명이 아니다.
출력은 완성된 instruction 문자열 하나다. 제안/refinement 둘 다 원래 부모 기준으로 측정한다.
실제 system 전문은 `src/prompt_policy/edit_prompts.py`; 입력 예시는 `examples/contrastive_edit/`에 있다.
예시의 응답/수치는 합성이며 Qwen 실험 결과가 아니다.

## 검증과 반영

기존 개별 trajectory 부호 검사를 유지한다. 성공 각각 delta>0, 실패 각각 delta<0일 때 verified=true다.
동일 instruction/변화0/반대 방향 응답이 있으면 통과하지 못한다. 없는 reward class에 조건을 요구하지 않는다.
후보 점수는 문항 안에서 `(2*r-1)*delta`를 평균하고 문항들을 동일 가중 평균한 G다.
검증을 통과한 C/R 중 G가 큰 쪽을 반영한다. Refinement가 나빠지면 최초 제안을 선택할 수 있다.
둘 다 검증을 못 통과하면 부모를 유지한다. 동점이면 최초 제안을 유지한다.
이는 각 step의 동일 pool에서만 비교하는 값이며 서로 다른 step의 G를 전역 순위로 쓰지 않는다.

별도 epsilon은 없다. 부호 확인은 수치 안정성/통계적 유의성을 보증하지 않는다.
측정은 T1 full-vocab이므로 T0.6/top-p0.95/top-k20 sampling policy의 정확한 PG surrogate라고 부르지 않는다.

## 걷어낸 구성

Hypothesis/suspected component, ablation, patch anchor/JSON 출력, 복수 branch, 복수 refinement,
optimizer 누적 이력, token-window 진단, mixed-pair 조건, validation 채택 필터/최종 재선택을 제거했다.
이전 복잡한 mode를 fallback/legacy 구현으로 남기지 않는다. 옛 recipe는 captured source로만 재현한다.
기존 hypothesis 필드는 편집 의도 기록용 구현 선택이었다. 별도 hypothesis 탐색 알고리즘을 구현한 것이 아니다.
관련 연구 VISTA는 hypothesis generation과 prompt rewriting을 분리한다:
https://aclanthology.org/2026.acl-srw.8/
이와의 유사성을 새 기여로 주장하지 않는다. 현재 최소 루프에는 해당 구성요소를 사용하지 않는다.

## 선택·평가·기록

최종 prompt는 마지막으로 채택한 P다. Validation은 검색/채택/최종 선택에서 사용하지 않으며 accuracy=null이다.
마지막 prompt를 파일에 고정한 뒤 기존 CLI로 initial/selected test를 평가한다. 같은 prompt면 test를 재사용한다.
`optimizer_calls.jsonl`은 실제 두 system/user prompt, 원문 출력과 IDs를 기록한다.
`trajectories.jsonl`, `likelihood.jsonl`, `edits.jsonl`, `decisions.jsonl`은 원본 응답, 측정 및 채택을 기록한다.
기존 config/manifest/candidates/selection/result/test 기록을 재사용한다. 불완전 optimizer 출력은 기록 후 실패한다.
Source/model/input hashes와 task sampling/출력 규칙은 기존 artifact 계약을 유지한다.
