# Code map

| Responsibility | Extension point |
|---|---|
| CLI, dry-run, provenance, final validation-only selection and test | `src/prompt_policy/cli.py` |
| Standalone TOML validation | `src/prompt_policy/config.py` |
| JSONL split identity and task reward | `src/prompt_policy/benchmarks.py` |
| Local Qwen/HF rendering, generation and model identity | `src/prompt_policy/backends.py::LocalHFBackend` |
| Exact token logprob calculation and immutable-response cache | `src/prompt_policy/scoring.py` |
| Question-balanced objective and accuracy guard | `src/prompt_policy/objective.py` |
| GEPA integration | `src/prompt_policy/optimizer.py` |
| GEPA task/reward/feedback adapter | `TaskAdapter` |
| Local acceptance hook with frozen parent trajectories | `LikelihoodAcceptance` |
| Same-model reflection | `LocalReflection` |
| Actual-rollout/iteration limits | `SearchStopper` |
| Append-only records and cost accounting | `src/prompt_policy/artifacts.py` |

GEPA source is an unmodified pinned snapshot in `vendor/gepa/`, installed through the uv path
source. Its `AcceptanceCriterion` hook supplies the full proposal, before/after captures and
optimizer state. This avoids patching GEPA or replacing its search, reflection, Pareto selection,
validation and native state machinery. Verify the source inventory before every CLI invocation.

Keep task reward, likelihood measurement, local acceptance and final evaluation separate. New
objectives extend `objective.py` and `LikelihoodAcceptance`; they must not alter benchmark reward
or write a relative local gain into GEPA's global scores. A future TextGrad proposal backend can
reuse `TrajectoryScorer`, `Trajectory` and the objective without importing consolidation code.

The serial numerical kernel was adapted from the reference listed in `SOURCE_PROVENANCE.json`.
Unlike that Qwen-specific unmasked right-padding path, it does not batch/pad trajectories. Numerical
tests compare it with full causal-LM logits on a tiny random Qwen3 model and chunk-size changes.

Archived TextGrad likelihood audits use `prompt_policy.analysis.textgrad_likelihood`.
The standalone TOML declares source run IDs, the original validation selection and repeat8
evaluation identities, exact model revision, reconstruction rules and GPU. The reader validates
original rewards and parent/proposal/acceptance links, then reuses the same causal hidden-state
alignment as the scorer. It performs no generation and never imports another project.

Completed audits are independently verified by `prompt_policy.analysis.textgrad_report`, which
checks token caches, original/repeated validation attribution and input hashes before writing a
cross-run report. See [TextGrad likelihood analysis](textgrad-likelihood.md) for the statistic,
policy-gradient interpretation, sampling limitations and commands.

Base-to-final selected endpoint comparisons use `prompt_policy.analysis.textgrad_endpoints`.
They fix original base-validation responses, verify and copy exact cached contexts, and score
missing endpoint contexts with the existing numerical kernel. Endpoint identity is checked
against each native summary and the actual accepted parent chain.

Historical DSPy DAPO endpoints use the same endpoint module with explicit
`task_format=dspy_chat_adapter_v1`. `build_legacy_inputs` reads actual captured endpoint messages,
checks identical wrapper/question history, and verifies all saved rewards via `legacy_dapo_score`.
A cache is optional; the no-cache path hashes the pinned model files and scores all contexts.

Historical candidate-origin comparisons extend the same endpoint reader through explicit
`response_origins` and `include_origin_context`. `make_origin_report` separates final-minus-base
from final-minus-origin, preserves accepted/rejected branch identity, and reports each origin
without pooling. Exact cached endpoint score files can be reused after ID/hash checks.

Online TextGrad prompt search extends the existing CLI using a `[textgrad]` configuration section.
`textgrad_optimizer.py` supplies only local forward capture, numerical string losses, an EngineLM
adapter, and admission/selection; upstream `LLMCall.backward`, `StringBasedFunction`, `sum` and
`TextualGradientDescent` are unchanged and verified against `vendor/textgrad/UPSTREAM.json`.
`objective.py::fixed_success_gain` retains failed rollouts in the per-question denominator and
`textgrad_eligibility` enforces positive sequence gain plus a validation-accuracy guard. The benchmark
module owns optional historical DSPy rendering/scoring; reflection requests always use plain messages.


The minimal likelihood-editing loop uses the existing CLI with empty `[edit_refinement]`
and `[objective] mode="directional_likelihood"`. `edit_optimizer.py::search` performs only:
train minibatch rollouts, one full-instruction proposal, exact-ID likelihood measurement,
one full-instruction refinement, another measurement, and adoption of the better verified improvement.
It reuses the existing backend, benchmark reward, `TrajectoryScorer` and final CLI test path.
It does not import GEPA or TextGrad, emit hypothesis records/patches, branch, ablate, accumulate optimizer
history, or perform validation filtering/selection. The final selected prompt is the last accepted update.
`edit_prompts.py` owns the two concise system strings and the request renderer. The proposer
receives labeled plain-text task/reward evidence. The refiner receives the same format plus parent
mean logprob, candidate P', and per-response mean-logprob changes; no sequence logprob is shown to the LLM.
Both return only the full instruction. The renderer selects one of two predefined feedback sentences
from the computed verification boolean; semantic diagnosis is performed by the refiner, not the renderer.
Internal verification/ranking still use sequence sums; raw numerical records retain both units.
`objective.py::fixed_directional_gain` checks individual success/failure directions and computes
an equal-question mean signed sequence gain. Validation accuracy stays null, not a likelihood score.

The removed candidate-first contrastive/directional design is not maintained as an extra code path.
Completed historical runs keep their exact source snapshots and artifacts; old complex recipes require
those snapshots and are rejected by the current minimal schema. Existing GEPA/TextGrad paths and
vendored snapshots are independent and unchanged. `top_k` is configurable for task/reflection sampling;
T=1 full-vocabulary likelihood measurement remains distinct from the sampling policy.
See [the minimal pipeline](contrastive-edit-refinement.md) and
[the current condition](../experiments/directional_edit_dapo_pilot/plan_report.md).

Fixed `Answer: <integer>` tasks use paired `benchmark.task_format` / `scorer` values
`answer_integer_v1`. `benchmarks.py::ANSWER_INTEGER_RULE` is appended to P by `task_messages`,
while `extract_answer_integer` parses only the final nonempty line outside thinking.
The fixed rule is included in benchmark identity, CLI preview and run provenance, and never
enters the editable parent string. The existing backend uses this same renderer for generation
and teacher forcing; reflection calls retain their separate proposer/refiner interfaces.
Historical `dapo_dspy_v1` rendering/reward and TextGrad source are unchanged.


Local vLLM serving reuses `backends.py::VLLMBackend` through optional `[serving]` in the
existing standalone TOML/CLI. `generate_batch` submits independent rollout requests concurrently
and preserves example/repeat order; the HF fallback remains serial. The same helper batches final
test requests after prompt selection is frozen. No new CLI or optimization component is introduced.
The backend renders the pinned tokenizer's chat template locally, supplies exact integer prompt IDs
to `/v1/completions`, and requires actual returned completion IDs including EOS. Reflection keeps
plain system/user rendering. The local serving manifest and live model path/context/version are
checked and recorded. Generation uses configured temperature/top-p/top-k. Teacher forcing sends
prefix + fixed response IDs with `prompt_logprobs=0`, T=1, top-p=1 and top-k=-1; it selects the
actual response token at positions starting at prefix length. One mandatory dummy continuation is
discarded. No text retokenization, response truncation, sampling seed or API retry is introduced.
`Recorder` protects concurrent generation cost increments. `progress.json` and stdout expose the
current scientific phase; original detailed JSONL records remain the scientific evidence.
