from __future__ import annotations

import time
from pathlib import Path

from prompt_policy.artifacts import Recorder, file_sha256
from prompt_policy.benchmarks import task_messages
from prompt_policy.scoring import token_logprobs
from prompt_policy.types import Generation


def local_model_identity(config):
    from huggingface_hub import snapshot_download

    source = config["model"]["name_or_path"]
    root = Path(source).expanduser()
    if not root.is_dir():
        root = Path(snapshot_download(source, revision=config["model"]["revision"]))
    root = root.resolve()
    files = sorted(
        p
        for p in root.rglob("*")
        if p.is_file() and p.suffix in {".json", ".safetensors", ".bin", ".model", ".txt", ".jinja"}
    )
    if not any(p.suffix in {".safetensors", ".bin"} for p in files):
        raise ValueError("Local model has no weight files")
    identity = {
        "source": source,
        "resolved_path": str(root),
        "revision": config["model"]["revision"],
        "files": {str(p.relative_to(root)): file_sha256(p) for p in files},
        "dtype": config["model"]["dtype"],
        "scoring_temperature": 1.0,
        "enable_thinking": config["generation"]["enable_thinking"],
    }
    return root, identity


class LocalHFBackend:
    """One frozen local causal LM for task generation, reflection and scoring."""

    def __init__(self, config: dict, recorder: Recorder):
        import torch
        from transformers import AutoModelForCausalLM, AutoTokenizer

        self.config, self.recorder = config, recorder
        root, self.identity = local_model_identity(config)
        dtype = getattr(torch, config["model"]["dtype"])
        self.tokenizer = AutoTokenizer.from_pretrained(root, trust_remote_code=False)
        self.model = AutoModelForCausalLM.from_pretrained(root, dtype=dtype, trust_remote_code=False)
        self.model.to(config["model"]["device"]).eval()
        self.model.requires_grad_(False)
        eos = self.model.generation_config.eos_token_id
        if eos is None:
            eos = self.tokenizer.eos_token_id
        self.eos_ids = {eos} if isinstance(eos, int) else set(eos or [])
        self.pad_id = self.tokenizer.pad_token_id
        if self.pad_id is None:
            self.pad_id = next(iter(sorted(self.eos_ids)), None)
        if self.pad_id is None:
            raise ValueError("Tokenizer/model must supply a pad or EOS token")

    def messages(self, prompt: str, question: str) -> list[dict]:
        return task_messages(prompt, question, self.config.get("benchmark", {}).get("task_format", "plain"))

    def prompt_ids(self, prompt: str, question: str) -> tuple[int, ...]:
        return self._encode_messages(self.messages(prompt, question))

    def _encode_messages(self, messages):
        ids = self.tokenizer.apply_chat_template(
            messages,
            tokenize=True,
            add_generation_prompt=True,
            enable_thinking=self.config["generation"]["enable_thinking"],
        )
        # Transformers versions may return either flat IDs or BatchEncoding.
        if hasattr(ids, "keys"):
            ids = ids["input_ids"]
        if ids and isinstance(ids[0], list):
            if len(ids) != 1:
                raise ValueError("Expected exactly one request")
            ids = ids[0]
        return tuple(ids)

    def _check_length(self, size: int):
        model_limit = getattr(self.model.config, "max_position_embeddings", None)
        limits = [self.config["model"]["max_context_tokens"]]
        if isinstance(model_limit, int):
            limits.append(model_limit)
        if size > min(limits):
            raise ValueError(f"Request needs {size} tokens; truncation is not permitted")

    def generate(self, prompt: str, question: str, *, reflection: bool = False) -> Generation:
        import torch

        settings = self.config["reflection"] if reflection else self.config["generation"]
        prefix = (
            self._encode_messages(task_messages(prompt, question))
            if reflection
            else self.prompt_ids(prompt, question)
        )
        self._check_length(len(prefix) + settings["max_new_tokens"])
        inputs = torch.tensor([prefix], device=next(self.model.parameters()).device, dtype=torch.long)
        kwargs = {
            "max_new_tokens": settings["max_new_tokens"],
            "pad_token_id": self.pad_id,
            "do_sample": settings["temperature"] > 0,
            "num_beams": 1,
            "repetition_penalty": 1.0,
            "use_cache": True,
        }
        if settings["temperature"] > 0:
            kwargs.update(
                temperature=settings["temperature"],
                top_p=settings["top_p"],
                top_k=settings.get("top_k", 0),
            )
        started = time.perf_counter()
        with torch.inference_mode():
            sequences = self.model.generate(
                input_ids=inputs, attention_mask=torch.ones_like(inputs), **kwargs
            )
        response = tuple(sequences[0, len(prefix) :].cpu().tolist())
        if not response:
            raise ValueError("Model produced an empty response")
        finish = "eos" if response[-1] in self.eos_ids else "length"
        # Strip only actual terminal EOS from display text; keep it in scored IDs.
        displayed = response[:-1] if finish == "eos" else response
        text = self.tokenizer.decode(displayed, skip_special_tokens=False)
        # Preserve completion text; separately record thinking begun by the request.
        prefix_text = self.tokenizer.decode(prefix, skip_special_tokens=False)
        thinking_open = prefix_text.rstrip().endswith("<think>")
        kind = "reflection" if reflection else "task"
        self.recorder.charge(
            kind,
            prompt_tokens=len(prefix),
            response_tokens=len(response),
            elapsed=time.perf_counter() - started,
        )
        return Generation(text, prefix, response, finish, thinking_open)

    def decode_tokens(self, token_ids):
        return self.tokenizer.decode(token_ids, skip_special_tokens=False)

    def logprobs(self, prompt_ids: tuple[int, ...], response_ids: tuple[int, ...]) -> tuple[float, ...]:
        self._check_length(len(prompt_ids) + len(response_ids))
        return token_logprobs(
            self.model, prompt_ids, response_ids, head_chunk=self.config["model"]["head_chunk"]
        )


class VLLMBackend(LocalHFBackend):
    """Local chat rendering, exact-ID completions and T=1 prompt scoring over HTTP."""

    def __init__(self, config: dict, recorder: Recorder):
        import json

        from transformers import AutoConfig, AutoTokenizer, GenerationConfig

        self.config, self.recorder = config, recorder
        root, self.identity = local_model_identity(config)
        self.tokenizer = AutoTokenizer.from_pretrained(root, trust_remote_code=False)
        model_config = AutoConfig.from_pretrained(root, trust_remote_code=False)
        if config["model"]["max_context_tokens"] > model_config.max_position_embeddings:
            raise ValueError("Server context must not exceed the pinned model context")
        eos = GenerationConfig.from_pretrained(root).eos_token_id
        self.eos_ids = {eos} if isinstance(eos, int) else set(eos or [self.tokenizer.eos_token_id])
        self.serving = config["serving"]
        manifest_path = Path(self.serving["server_manifest"])
        manifest = json.loads(manifest_path.read_text())
        expected = {
            "model_path": str(root),
            "revision": config["model"]["revision"],
            "dtype": config["model"]["dtype"],
            "max_context_tokens": config["model"]["max_context_tokens"],
            "served_model": self.serving["model"],
            "base_url": self.serving["base_url"],
        }
        if any(manifest.get(k) != v for k, v in expected.items()):
            raise ValueError("Serving manifest differs from the requested model/protocol")
        advertised = self._request("/models", None)
        matches = [m for m in advertised["data"] if m["id"] == self.serving["model"]]
        if len(matches) != 1 or matches[0].get("root") != str(root):
            raise ValueError("Live server does not advertise the pinned local model path")
        if matches[0].get("max_model_len") != config["model"]["max_context_tokens"]:
            raise ValueError("Live server context differs from the requested context")
        version = self._request("/version", None, version=True)["version"]
        if version != manifest["vllm_version"]:
            raise ValueError("Live server version differs from serving manifest")
        self.identity.update(
            backend="vllm_openai_completions",
            server=manifest,
            server_manifest_sha256=file_sha256(manifest_path),
        )

    def _request(self, path, payload, *, version=False):
        import json
        import urllib.error
        import urllib.request

        base = self.serving["base_url"].removesuffix("/v1") if version else self.serving["base_url"]
        body = None if payload is None else json.dumps(payload, allow_nan=False).encode()
        request = urllib.request.Request(base + path, data=body, headers={"Content-Type": "application/json"})
        try:
            with urllib.request.urlopen(request, timeout=self.serving["timeout_seconds"]) as response:
                return json.load(response)
        except urllib.error.HTTPError as error:
            raise ValueError(f"vLLM HTTP {error.code}: {error.read().decode()}") from error

    def _check_length(self, size):
        if size > self.config["model"]["max_context_tokens"]:
            raise ValueError(f"Request needs {size} tokens; truncation is not permitted")

    def _completion(self, prefix, **settings):
        result = self._request(
            "/completions",
            {
                "model": self.serving["model"],
                "prompt": list(prefix),
                "return_token_ids": True,
                "skip_special_tokens": False,
                "repetition_penalty": 1.0,
                "presence_penalty": 0.0,
                "frequency_penalty": 0.0,
                **settings,
            },
        )
        if len(result["choices"]) != 1:
            raise ValueError("Expected exactly one completion")
        choice = result["choices"][0]
        if tuple(choice.get("prompt_token_ids") or ()) != tuple(prefix):
            raise ValueError("Server changed the supplied prompt token IDs")
        return choice

    def generate(self, prompt, question, *, reflection=False):
        settings = self.config["reflection"] if reflection else self.config["generation"]
        prefix = (
            self._encode_messages(task_messages(prompt, question))
            if reflection
            else self.prompt_ids(prompt, question)
        )
        self._check_length(len(prefix) + settings["max_new_tokens"])
        started = time.perf_counter()
        choice = self._completion(
            prefix,
            max_tokens=settings["max_new_tokens"],
            temperature=settings["temperature"],
            top_p=settings["top_p"],
            top_k=settings.get("top_k", 0) or -1,
        )
        ids = choice.get("token_ids")
        if not ids or any(type(t) is not int for t in ids):
            raise ValueError("vLLM must return actual generated token IDs; text retokenization is forbidden")
        response = tuple(ids)
        if choice["finish_reason"] == "length":
            finish = "length"
        elif choice["finish_reason"] == "stop" and response[-1] in self.eos_ids:
            finish = "eos"
        else:
            raise ValueError("Completion stop did not retain an actual EOS token")
        displayed = response[:-1] if finish == "eos" else response
        text = self.tokenizer.decode(displayed, skip_special_tokens=False)
        self.recorder.charge(
            "reflection" if reflection else "task",
            prompt_tokens=len(prefix),
            response_tokens=len(response),
            elapsed=time.perf_counter() - started,
        )
        return Generation(
            text, prefix, response, finish, self.decode_tokens(prefix).rstrip().endswith("<think>")
        )

    def generate_many(self, prompt, questions):
        from concurrent.futures import ThreadPoolExecutor

        with ThreadPoolExecutor(max_workers=self.serving["max_concurrency"]) as pool:
            return list(pool.map(lambda q: self.generate(prompt, q), questions))

    def logprobs(self, prompt_ids, response_ids):
        # One dummy continuation is discarded; only supplied, fixed response IDs are scored.
        joined = tuple(prompt_ids) + tuple(response_ids)
        self._check_length(len(joined) + 1)
        choice = self._completion(
            joined, max_tokens=1, temperature=1.0, top_p=1.0, top_k=-1, min_p=0.0, prompt_logprobs=0
        )
        rows = choice.get("prompt_logprobs")
        if rows is None or len(rows) != len(joined):
            raise ValueError("vLLM prompt logprobs must cover every supplied token position")
        result = []
        for position, token_id in enumerate(response_ids, len(prompt_ids)):
            row = rows[position]
            if row is None or str(token_id) not in row:
                raise ValueError("Missing fixed-response token logprob at its causal position")
            result.append(float(row[str(token_id)]["logprob"]))
        return tuple(result)


def generate_batch(backend, prompt, questions):
    """Preserve input order; local HF and test backends retain the serial fallback."""
    if hasattr(backend, "generate_many"):
        return backend.generate_many(prompt, questions)
    return [backend.generate(prompt, question) for question in questions]
