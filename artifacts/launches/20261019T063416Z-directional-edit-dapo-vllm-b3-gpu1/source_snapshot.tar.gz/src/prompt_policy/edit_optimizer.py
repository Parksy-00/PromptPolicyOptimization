"""Minibatch rollouts -> instruction proposal -> likelihood -> one refinement -> update."""

from __future__ import annotations

import random
from dataclasses import dataclass

from prompt_policy.artifacts import digest
from prompt_policy.backends import generate_batch
from prompt_policy.benchmarks import ANSWER_INTEGER_RULE
from prompt_policy.edit_prompts import PROPOSER_SYSTEM, REFINER_SYSTEM, request_payload
from prompt_policy.objective import fixed_directional_gain
from prompt_policy.scoring import TrajectoryScorer
from prompt_policy.types import Trajectory


def minibatches(examples, size, iterations, seed):
    rng, remaining = random.Random(seed), []
    for _ in range(iterations):
        if not remaining:
            remaining = list(examples)
            rng.shuffle(remaining)
        batch, remaining = remaining[:size], remaining[size:]
        yield batch


def optimizer_call(backend, recorder, phase, request, iteration):
    system = PROPOSER_SYSTEM if phase == "propose" else REFINER_SYSTEM
    generated = backend.generate(system, request, reflection=True)
    text = ("<think>" if generated.thinking_open_in_prefix else "") + generated.text
    instruction = text.rsplit("</think>", 1)[-1].strip()
    invalid = generated.finish_reason == "length" or not instruction or "<think>" in instruction
    recorder.append(
        "optimizer_calls.jsonl",
        {
            "iteration": iteration,
            "phase": phase,
            "system_prompt": system,
            "request": request,
            **generated.__dict__,
            "instruction": instruction,
            "error": "incomplete optimizer instruction" if invalid else None,
        },
    )
    if invalid:
        raise ValueError("Incomplete optimizer instruction; see optimizer_calls.jsonl")
    return instruction


@dataclass
class EditResult:
    candidates: list[dict]
    best_idx: int
    total_metric_calls: int

    @property
    def best_candidate(self):
        return {"system_prompt": self.candidates[self.best_idx]["prompt"]}

    @property
    def val_aggregate_scores(self):
        # This optimizer performs no validation selection or validation filtering.
        return [None] * len(self.candidates)

    def to_dict(self):
        return {
            "optimizer": "edit_refinement",
            "candidates": self.candidates,
            "best_idx": self.best_idx,
            "total_metric_calls": self.total_metric_calls,
        }


def search(benchmark, backend, recorder, config):
    limits, parent = config["search"], config["initial_prompt"]
    scorer = TrajectoryScorer(backend, recorder)
    candidates = [{"prompt": parent, "parent_idx": None, "kind": "initial"}]
    current_idx = 0
    output_rule = (
        ANSWER_INTEGER_RULE
        if benchmark.scorer == "answer_integer_v1"
        else ("Give the final answer after ### or Answer:, or in a balanced \\boxed{...}.")
    )
    for iteration, examples in enumerate(
        minibatches(
            benchmark.train, limits["minibatch_size"], limits["max_iterations"], limits["search_seed"]
        )
    ):
        if (
            recorder.cost["task_calls"] + len(examples) * limits["train_rollouts"]
            > limits["max_task_rollouts"]
        ):
            break
        print(f"Step {iteration}: rollout start ({len(examples)} questions)", flush=True)
        recorder.write("progress.json", {"iteration": iteration, "phase": "rollout"})
        references, rollouts = [], []
        jobs = [(e, r) for e in examples for r in range(limits["train_rollouts"])]
        generated_batch = generate_batch(backend, parent, [e.question for e, _ in jobs])
        for (example, repeat), generated in zip(jobs, generated_batch, strict=True):
            reward = benchmark.score(
                example, generated.text, thinking_open_in_prefix=generated.thinking_open_in_prefix
            )
            t = Trajectory(
                example.id,
                example.question,
                "train",
                repeat,
                parent,
                generated.text,
                generated.prompt_ids,
                generated.response_ids,
                reward,
                generated.finish_reason,
                generated.thinking_open_in_prefix,
            )
            references.append(t)
            recorder.append("trajectories.jsonl", {"iteration": iteration, **t.to_dict()})
            rollouts.append(
                {
                    "example_id": example.id,
                    "repeat_index": repeat,
                    "question": example.question,
                    "gold_answer": example.answer,
                    "response": generated.text,
                    "reward": reward,
                }
            )
        print(
            f"Step {iteration}: rollout rewards={[t.reward for t in references]} "
            f"tokens={[len(t.response_ids) for t in references]}",
            flush=True,
        )
        recorder.write(
            "progress.json",
            {"iteration": iteration, "phase": "proposal", "rewards": [t.reward for t in references]},
        )
        pool_hash = digest([t.to_dict() for t in references])

        proposal = optimizer_call(
            backend, recorder, "propose", request_payload(parent, rollouts, output_rule), iteration
        )
        proposal_eval = fixed_directional_gain(parent, proposal, references, scorer)
        recorder.append(
            "edits.jsonl",
            {
                "iteration": iteration,
                "phase": "proposal",
                "instruction": proposal,
                "pool_sha256": pool_hash,
                **proposal_eval,
            },
        )

        print(
            f"Step {iteration}: proposal verified={proposal_eval['verified']} "
            f"mean_deltas={[round(r['delta_mean_logprob'], 6) for r in proposal_eval['trajectories']]}",
            flush=True,
        )
        recorder.write("progress.json", {"iteration": iteration, "phase": "refinement"})
        refined = optimizer_call(
            backend,
            recorder,
            "refine",
            request_payload(parent, rollouts, output_rule, candidate=proposal, evaluation=proposal_eval),
            iteration,
        )
        refined_eval = fixed_directional_gain(parent, refined, references, scorer)
        recorder.append(
            "edits.jsonl",
            {
                "iteration": iteration,
                "phase": "refinement",
                "instruction": refined,
                "pool_sha256": pool_hash,
                **refined_eval,
            },
        )

        print(
            f"Step {iteration}: refinement verified={refined_eval['verified']} "
            f"mean_deltas={[round(r['delta_mean_logprob'], 6) for r in refined_eval['trajectories']]}",
            flush=True,
        )
        eligible = [("proposal", proposal, proposal_eval), ("refinement", refined, refined_eval)]
        eligible = [c for c in eligible if c[2]["verified"] and c[2]["score"] > 0]
        winner = max(eligible, key=lambda c: c[2]["score"]) if eligible else None
        old_parent = parent
        if winner:
            phase, parent, evaluation = winner
            candidates.append(
                {
                    "prompt": parent,
                    "parent_idx": current_idx,
                    "kind": phase,
                    "iteration": iteration,
                    "train_signed_gain": evaluation["score"],
                }
            )
            current_idx = len(candidates) - 1
        recorder.append(
            "decisions.jsonl",
            {
                "iteration": iteration,
                "parent_prompt": old_parent,
                "selected_prompt": parent,
                "accepted": winner is not None,
                "phase": winner[0] if winner else None,
                "score": winner[2]["score"] if winner else 0.0,
                "pool_sha256": pool_hash,
            },
        )
        recorder.write(
            "progress.json",
            {
                "iteration": iteration,
                "phase": "decision",
                "accepted": winner is not None,
                "accepted_updates": current_idx,
            },
        )
        print(
            f"Step {iteration}: proposal={proposal_eval['score']:+.6f} "
            f"refinement={refined_eval['score']:+.6f} accepted={winner is not None}",
            flush=True,
        )
    return EditResult(candidates, current_idx, recorder.cost["task_calls"])
