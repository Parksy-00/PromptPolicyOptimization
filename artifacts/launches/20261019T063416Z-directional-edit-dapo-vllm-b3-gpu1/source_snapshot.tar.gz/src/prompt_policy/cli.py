from __future__ import annotations

import argparse
import importlib.metadata
import json
import os
import statistics
import subprocess
import sys
import time
from datetime import datetime, timezone
from pathlib import Path
from uuid import uuid4

from prompt_policy.artifacts import Recorder, digest, file_sha256
from prompt_policy.config import load_config, resolve_model


def verify_gepa(root: Path) -> dict:
    """Reject modified source or an accidentally installed, unpinned PyPI GEPA."""
    import gepa

    manifest = json.loads((root / "vendor/gepa/UPSTREAM.json").read_text())
    for relative, expected in manifest["files_sha256"].items():
        if file_sha256(root / "vendor/gepa" / relative) != expected:
            raise ValueError(f"Vendored GEPA differs from pinned source: {relative}")
    actual = Path(gepa.__file__).resolve().parent
    if actual != (root / "vendor/gepa/src/gepa").resolve():
        raise ValueError("GEPA must be loaded from vendor/gepa; install with uv sync --frozen")
    return {"repository": manifest["repository"], "revision": manifest["revision"], "patches": []}


def source_identity(root: Path) -> dict:
    try:
        revision = subprocess.check_output(
            ["git", "rev-parse", "HEAD"], cwd=root, text=True, stderr=subprocess.DEVNULL
        ).strip()
    except subprocess.CalledProcessError:
        revision = None
    paths = sorted((root / "src").rglob("*.py")) + [root / "pyproject.toml", root / "uv.lock"]
    return {"git_commit": revision, "files_sha256": {str(p.relative_to(root)): file_sha256(p) for p in paths}}


def evaluate_test(benchmark, backend, recorder, prompt, repeats, label):
    from prompt_policy.backends import generate_batch

    results, per_repeat = [], [[] for _ in range(repeats)]
    jobs = [(e, r) for e in benchmark.test for r in range(repeats)]
    generated_batch = iter(generate_batch(backend, prompt, [e.question for e, _ in jobs]))
    for example in benchmark.test:
        values = []
        for repeat in range(repeats):
            generated = next(generated_batch)
            score = benchmark.score(
                example, generated.text, thinking_open_in_prefix=generated.thinking_open_in_prefix
            )
            values.append(score)
            per_repeat[repeat].append(score)
            recorder.append(
                "test.jsonl",
                {
                    "condition": label,
                    "prompt": prompt,
                    "example_id": example.id,
                    "question": example.question,
                    "split": "test",
                    "repeat_index": repeat,
                    "text": generated.text,
                    "reward": score,
                    "finish_reason": generated.finish_reason,
                    "thinking_open_in_prefix": generated.thinking_open_in_prefix,
                    "prompt_ids": generated.prompt_ids,
                    "response_ids": generated.response_ids,
                },
            )
        results.append({"example_id": example.id, "accuracy": statistics.mean(values)})
    repeat_means = [statistics.mean(values) for values in per_repeat]
    return {
        "accuracy": statistics.mean(repeat_means),
        "repeat_accuracies": repeat_means,
        "repeat_std": statistics.stdev(repeat_means) if repeats > 1 else None,
        "questions": len(results),
        "rollouts": len(results) * repeats,
        "per_question": results,
    }


def run(config_path: Path, *, dry_run=False, output: Path | None = None):
    config_path = config_path.resolve()
    root = Path(__file__).resolve().parents[2]
    config, benchmark = load_config(config_path)
    config, missing = resolve_model(config, config_path.parent)
    if "edit_refinement" in config:
        from prompt_policy.edit_prompts import PROPOSER_SYSTEM, REFINER_SYSTEM

        optimizer_name = "edit_refinement"
        upstream = {
            "implementation": "minimal propose-measure-refine/v3",
            "proposer_sha256": digest(PROPOSER_SYSTEM),
            "refiner_sha256": digest(REFINER_SYSTEM),
        }
    elif "textgrad" in config:
        from prompt_policy.textgrad_optimizer import verify_textgrad

        upstream = verify_textgrad()
        optimizer_name = "textgrad"
    else:
        upstream = verify_gepa(root)
        optimizer_name = "gepa"
    plan = {
        "executable": not missing,
        "missing": missing,
        "config": config,
        "benchmark": benchmark.identity,
        optimizer_name: upstream,
        "optimizer": optimizer_name,
        "objective": (
            "verify each observed success increases and each observed failure decreases; "
            "rank by question-balanced signed likelihood gain; single-class pools are eligible"
            if optimizer_name == "edit_refinement"
            else "maximize fixed-parent reward-weighted sequence logprob gain, require G>tolerance; validation guard"
            if config["objective"]["mode"] == "success_likelihood_ascent"
            else "validation accuracy"
            if optimizer_name == "textgrad"
            else "delta_accuracy + weight * question_balanced_mean_delta_logprob_T1"
        ),
        "final_selection": "last_verified_prompt"
        if optimizer_name == "edit_refinement"
        else "validation_accuracy_only",
        "notes": [
            "No sampling seeds are sent; search_seed controls search minibatches only.",
            (
                "Optimizer reserves each complete iteration; missing-evidence batches can use less."
                if optimizer_name in {"textgrad", "edit_refinement"}
                else "Budget checked between complete iterations; the last iteration can exceed it."
            ),
            "Built-in JSONL scorers do not claim canonical DAPO/GPQA equivalence.",
        ],
    }
    if config["benchmark"].get("task_format") == "answer_integer_v1":
        from prompt_policy.benchmarks import ANSWER_INTEGER_RULE, task_messages

        plan["task_interface"] = {
            "task_format": "answer_integer_v1",
            "editable_component": "instruction_only",
            "initial_instruction": config["initial_prompt"],
            "fixed_output_rule": ANSWER_INTEGER_RULE,
            "initial_task_messages_example": task_messages(
                config["initial_prompt"], benchmark.train[0].question, "answer_integer_v1"
            ),
            "answer_filter": "last nonempty line outside thinking: Answer: [+-]?[0-9]+; integer equality",
        }
    if optimizer_name == "edit_refinement":
        from prompt_policy.edit_optimizer import minibatches

        plan["train_minibatch_schedule"] = [
            [e.id for e in batch]
            for batch in minibatches(
                benchmark.train,
                config["search"]["minibatch_size"],
                config["search"]["max_iterations"],
                config["search"]["search_seed"],
            )
        ]
        plan["optimizer_prompts"] = {"proposer_system": PROPOSER_SYSTEM, "refiner_system": REFINER_SYSTEM}
        plan["pipeline"] = [
            "train minibatch rollouts and task rewards",
            "diagnose failures and reproduce successes -> one complete instruction proposal",
            "score the exact fixed parent response IDs under parent and proposal",
            "one refinement using measured changes -> score the same fixed responses",
            "apply the better direction-verified improvement, or keep parent",
            "freeze the last accepted prompt before initial/selected test",
        ]
        plan["edit_limits_per_outer_iteration"] = {
            "optimizer_calls": 2,
            "measured_candidates": 2,
            "task_rollouts_reserved": config["search"]["minibatch_size"] * config["search"]["train_rollouts"],
        }
        plan["notes"].extend(
            [
                "No validation filtering/selection; validation_accuracy is null (not measured).",
                "Each success must increase and each failure decrease; all reward compositions are used.",
                "The proposer receives task/reward evidence; the refiner additionally receives numerical changes.",
                "T=1 full-vocabulary sequence likelihood differs from the truncated sampling policy.",
            ]
        )
    if dry_run:
        print(json.dumps(plan, indent=2, ensure_ascii=False))
        return plan
    if missing:
        raise ValueError("Missing configuration: " + "; ".join(missing))
    run_id = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ") + "-" + uuid4().hex[:8]
    run_dir = (output or root / "artifacts/runs" / run_id).resolve()
    run_dir.mkdir(parents=True, exist_ok=False)
    recorder = Recorder(run_dir)
    started = time.perf_counter()
    manifest = {
        "schema": "prompt_policy_run/v1",
        "run_id": run_dir.name,
        "status": "running",
        "config_sha256": digest(config),
        "benchmark": benchmark.identity,
        "source": source_identity(root),
        optimizer_name: upstream,
        "optimizer": optimizer_name,
        "environment": {
            "python": sys.version,
            "cuda_visible_devices": os.environ.get("CUDA_VISIBLE_DEVICES"),
            "packages": {d.metadata["Name"]: d.version for d in importlib.metadata.distributions()},
        },
        "limits": plan["notes"],
    }
    if "task_interface" in plan:
        manifest["task_interface"] = plan["task_interface"]
    recorder.write("config.json", config)
    recorder.write("manifest.json", manifest)
    try:
        from prompt_policy.backends import LocalHFBackend, VLLMBackend

        if optimizer_name == "edit_refinement":
            from prompt_policy.edit_optimizer import search
        elif optimizer_name == "textgrad":
            from prompt_policy.textgrad_optimizer import search
        else:
            from prompt_policy.optimizer import search

        backend = (VLLMBackend if "serving" in config else LocalHFBackend)(config, recorder)
        manifest["model"] = backend.identity
        recorder.write("manifest.json", manifest)
        result = search(benchmark, backend, recorder, config)
        recorder.write("candidates.json", result.to_dict())
        selected = result.best_candidate["system_prompt"]
        # Selection is frozen and written before the test split is touched.
        recorder.write(
            "selection.json",
            {
                "candidate_idx": result.best_idx,
                "prompt": selected,
                "criterion": "last_verified_prompt"
                if optimizer_name == "edit_refinement"
                else "validation_accuracy",
            },
        )
        recorder.write("progress.json", {"phase": "test", "selected_candidate_idx": result.best_idx})
        print(f"Search complete: {result.best_idx} accepted updates; starting frozen-prompt test", flush=True)
        search_cost = dict(recorder.cost)
        tests = {}
        for label, prompt in [("initial", config["initial_prompt"]), ("selected", selected)]:
            if label == "selected" and selected == config["initial_prompt"]:
                tests[label] = {**tests["initial"], "reused_initial": True}
            else:
                tests[label] = evaluate_test(
                    benchmark, backend, recorder, prompt, config["search"]["test_rollouts"], label
                )
        recorder.write(
            "result.json",
            {
                "best_candidate_idx": result.best_idx,
                "selected_prompt": selected,
                "validation_accuracy": result.val_aggregate_scores[result.best_idx],
                "test": tests,
                "search_cost": search_cost,
                "total_cost": dict(recorder.cost),
                (
                    f"{optimizer_name}_total_metric_calls"
                    if optimizer_name in {"textgrad", "edit_refinement"}
                    else "gepa_total_metric_calls"
                ): result.total_metric_calls,
                "budget_counter": "search_cost.task_calls (actual individual task rollouts)",
            },
        )
        manifest["status"] = "complete"
        recorder.write("progress.json", {"phase": "complete", "selected_candidate_idx": result.best_idx})
    except BaseException as error:
        manifest["status"] = "interrupted" if isinstance(error, KeyboardInterrupt) else "failed"
        manifest["error"] = f"{type(error).__name__}: {error}"
        raise
    finally:
        manifest["elapsed_seconds"] = time.perf_counter() - started
        manifest["cost"] = dict(recorder.cost)
        recorder.write("manifest.json", manifest)
    print(f"Completed: {run_dir}")
    return run_dir


def main():
    parser = argparse.ArgumentParser(description="Independent prompt policy optimization")
    parser.add_argument("config", type=Path, help="Standalone experiment TOML")
    parser.add_argument(
        "--dry-run", action="store_true", help="Validate and report; no model load or generation"
    )
    parser.add_argument("--output", type=Path, help="New run directory; existing directories are refused")
    args = parser.parse_args()
    try:
        run(args.config, dry_run=args.dry_run, output=args.output)
    except (ValueError, FileNotFoundError, FileExistsError) as error:
        parser.exit(2, f"error: {error}\n")
