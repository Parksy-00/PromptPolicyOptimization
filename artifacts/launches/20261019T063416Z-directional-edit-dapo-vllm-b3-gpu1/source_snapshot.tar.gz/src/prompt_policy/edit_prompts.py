"""Two instruction-writing prompts for the minimal propose/measure/refine loop."""

PROPOSER_SYSTEM = """Improve the current task instruction using the observed rollouts.
For failed rollouts, diagnose what went wrong and write instructions that prevent the same failure.
For successful rollouts, identify useful behaviors and write instructions that help reproduce them.
Use whichever outcomes are available. Generalize; do not copy questions, answers or solutions.
Return only the complete updated instruction.
"""

REFINER_SYSTEM = """Inspect the current prompt, candidate edit and measured likelihood changes on fixed trajectories.
The desired update is to make successful trajectories more likely and failed trajectories less likely.
Infer which semantic component of the edit could have caused an undesirable likelihood shift,
and propose a revised instruction that reverses that shift. Preserve changes that moved in the desired direction.
Use the actual trajectory contents and the change from the current prompt to the candidate, not just the numbers.
When only successes or only failures are available, use those trajectories without inventing the missing class.
Generalize; do not copy questions, answers or solutions. Keep the fixed output rule separate and unchanged.
Return only the complete revised instruction.
"""


def request_payload(parent, rollouts, output_rule, *, candidate=None, evaluation=None):
    lines = [f"Current prompt P:\n{parent}", f"Fixed output rule (not editable):\n{output_rule}"]
    seen = set()
    measurements = (
        [(rollout, None) for rollout in rollouts]
        if candidate is None
        else list(zip(rollouts, evaluation["trajectories"], strict=True))
    )
    for index, (rollout, measurement) in enumerate(measurements, 1):
        if rollout["example_id"] not in seen:
            lines.append(
                f"Example x ({rollout['example_id']}):\n{rollout['question']}\n"
                f"Gold answer (optimizer only): {rollout['gold_answer']}"
            )
            seen.add(rollout["example_id"])
        outcome = "Successful" if rollout["reward"] == 1 else "Failed"
        text = f"{outcome} trajectory {index}:\n{rollout['response']}\nreward = {rollout['reward']:g}"
        if measurement is not None:
            text += f"\nmean log-prob under P = {measurement['parent_mean_logprob']:.12g}"
        lines.append(text)

    if candidate is None:
        lines.append(
            "Propose an updated instruction using the observed rollouts. "
            "Return only the complete updated instruction."
        )
        return "\n\n".join(lines)

    lines.append(f"Candidate edit P':\n{candidate}")
    for index, (rollout, measurement) in enumerate(measurements, 1):
        outcome = "successful" if rollout["reward"] == 1 else "failed"
        lines.append(
            f"{outcome} trajectory {index} likelihood change:\n"
            f"mean log-prob change = {measurement['delta_mean_logprob']:+.12g}"
        )
    lines.append("Measured direction verification: " + ("passed" if evaluation["verified"] else "failed"))
    lines.append(
        "This edit moves the observed trajectories in the desired directions."
        if evaluation["verified"]
        else "This edit is undesirable because at least one observed trajectory did not move in its required direction."
    )
    lines.append(
        "Infer which semantic component of the edit could have caused the observed likelihood shift, "
        "and propose a revised instruction that raises successful-trajectory likelihood and lowers "
        "failed-trajectory likelihood. If the observed directions were already desirable, preserve "
        "those changes while improving the instruction. Return only the complete revised instruction."
    )
    return "\n\n".join(lines)
