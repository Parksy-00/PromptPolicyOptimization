import json

import pytest

from prompt_policy.benchmarks import Benchmark, extract_answer, load_benchmark, reward
from prompt_policy.types import Example


@pytest.mark.parametrize("text", ["### 5", "Answer: 5", r"work \boxed{5}", "<think>### 999</think>\n### 5"])
def test_final_answer_formats(text):
    assert reward(text, "5", "numeric") == 1


def test_unclosed_thinking_and_unclosed_box_are_failures():
    assert extract_answer("<think>### 5") is None
    assert extract_answer(r"\boxed{5") is None
    assert extract_answer("5") is None


def test_thinking_started_in_request_is_not_mistaken_for_final_answer():
    benchmark = Benchmark("toy", "numeric", (), (), (), {})
    example = Example("a", "q", "5", "train")
    assert benchmark.score(example, "### 5", thinking_open_in_prefix=True) == 0
    assert benchmark.score(example, "thought </think>\n### 5", thinking_open_in_prefix=True) == 1


def test_numeric_is_exact_rational_not_float_approximation():
    assert reward("### 0.5", "1/2", "numeric") == 1
    assert reward("### 0.33333333", "1/3", "numeric") == 0
    assert reward("### nan", "5", "numeric") == 0


def test_split_overlap_fails_before_model_load(tmp_path):
    for split in ("train", "validation", "test"):
        (tmp_path / f"{split}.jsonl").write_text(
            json.dumps({"id": split, "question": "same question", "answer": "1"}) + "\n"
        )
    config = {
        "name": "test",
        "scorer": "numeric",
        **{s: f"{s}.jsonl" for s in ("train", "validation", "test")},
    }
    with pytest.raises(ValueError, match="Duplicate"):
        load_benchmark(config, tmp_path)


@pytest.mark.parametrize(
    "text,gold",
    [
        ("Reasoning\nAnswer: 35", "35"),
        ("Answer: -35", "-35"),
        ("Answer: +0035\n\n", "35"),
        ("<think>Answer: 999</think>\nReasoning\nAnswer: 35", "35"),
    ],
)
def test_fixed_answer_integer_accepts_only_the_final_answer_outside_thinking(text, gold):
    assert reward(text, gold, "answer_integer_v1") == 1


@pytest.mark.parametrize(
    "text",
    [
        "Reasoning mentions 35.",
        "Answer: 35\nMore reasoning",
        r"Answer: \boxed{35}",
        "Answer: 35.0",
        "Answer: 35/1",
        "Answer: 35 or 36",
        "Answer: 35.",
        "answer: 35",
        "Answer: ３５",
        "<think>Answer: 35",
        "<think>Answer: 35</think>\nNo final answer",
        "### 35",
    ],
)
def test_fixed_answer_integer_rejects_ambiguous_malformed_or_reasoning_only_answers(text):
    assert reward(text, "35", "answer_integer_v1") == 0


def test_fixed_answer_integer_preserves_negative_sign_and_prefix_thinking():
    benchmark = Benchmark("test", "answer_integer_v1", (), (), (), {})
    example = Example("a", "q", "35", "train")
    assert benchmark.score(example, "Answer: -35") == 0
    assert benchmark.score(example, "Answer: 35", thinking_open_in_prefix=True) == 0
    assert benchmark.score(example, "reasoning </think>\nAnswer: 35", thinking_open_in_prefix=True) == 1


def test_fixed_rule_is_outside_editable_instruction_and_does_not_affect_plain_reflection():
    from prompt_policy.benchmarks import ANSWER_INTEGER_RULE, task_messages

    parent = "Solve the problem."
    candidate = "Solve the problem and check your reasoning."
    before = task_messages(parent, "question", "answer_integer_v1")
    after = task_messages(candidate, "question", "answer_integer_v1")
    assert before[0]["content"] == parent + "\n\n" + ANSWER_INTEGER_RULE
    assert after[0]["content"] == candidate + "\n\n" + ANSWER_INTEGER_RULE
    assert before[1] == after[1] == {"role": "user", "content": "question"}
    assert task_messages("critic", "request")[0]["content"] == "critic"


def test_fixed_rule_and_scorer_are_paired_and_recorded_in_identity(tmp_path):
    from prompt_policy.benchmarks import ANSWER_INTEGER_RULE

    for split in ("train", "validation", "test"):
        (tmp_path / f"{split}.jsonl").write_text(
            json.dumps({"id": split, "question": f"{split} question", "answer": "35"}) + "\n"
        )
    config = {
        "name": "test",
        "scorer": "answer_integer_v1",
        "task_format": "answer_integer_v1",
        **{s: f"{s}.jsonl" for s in ("train", "validation", "test")},
    }
    benchmark = load_benchmark(config, tmp_path)
    assert benchmark.identity["fixed_output_rule"] == ANSWER_INTEGER_RULE
    assert benchmark.identity["task_format"] == "answer_integer_v1"
    for wrong in (config | {"task_format": "plain"}, config | {"scorer": "numeric"}):
        with pytest.raises(ValueError, match="used together"):
            load_benchmark(wrong, tmp_path)
    (tmp_path / "train.jsonl").write_text(
        json.dumps({"id": "train", "question": "tr", "answer": "35.0"}) + "\n"
    )
    with pytest.raises(ValueError, match="integer ground truth"):
        load_benchmark(config, tmp_path)
