import json
from dataclasses import replace
from pathlib import Path

import pytest
from conftest import FakeBackend

from prompt_policy.benchmarks import Benchmark
from prompt_policy.config import validate_config
from prompt_policy.edit_optimizer import search
from prompt_policy.edit_prompts import PROPOSER_SYSTEM, REFINER_SYSTEM
from prompt_policy.objective import fixed_directional_gain
from prompt_policy.scoring import Likelihood
from prompt_policy.types import Example, Generation, Trajectory


def configure(config):
    config["initial_prompt"] = "parent"
    config["objective"] = {"mode": "directional_likelihood"}
    config["edit_refinement"] = {}
    config["search"].pop("validation_rollouts", None)
    config["search"].update(minibatch_size=1, train_rollouts=2, max_iterations=1, max_task_rollouts=10)
    return Benchmark(
        "test_only",
        "answer_integer_v1",
        (Example("tr", "1+1", "2", "train"),),
        (Example("va", "2+2", "4", "validation"),),
        (Example("te", "3+3", "6", "test"),),
        {},
    )


class EditBackend(FakeBackend):
    def __init__(self, recorder, *, outcomes="both", refinement="refined", better_proposal=False):
        super().__init__(recorder)
        self.outcomes, self.refinement = outcomes, refinement
        self.better_proposal, self.task_index = better_proposal, 0

    def prompt_ids(self, prompt, question):
        return ({"parent": 1, "proposed": 2, "refined": 3, "suppressed": 4}[prompt], len(question) + 10)

    def generate(self, prompt, question, *, reflection=False):
        if reflection:
            text = "proposed" if prompt == PROPOSER_SYSTEM else self.refinement
            self.recorder.charge("reflection", prompt_tokens=2, response_tokens=2, elapsed=0)
            return Generation(text, (7,), (8, 9), "eos")
        good = self.outcomes == "successes_only" or (self.outcomes == "both" and self.task_index % 2 == 0)
        self.task_index += 1
        answer = sum(map(int, question.split("+"))) if good else 999
        self.recorder.charge("task", prompt_tokens=2, response_tokens=2, elapsed=0)
        return Generation(f"Answer: {answer}", self.prompt_ids(prompt, question), (answer, 9), "eos")

    def logprobs(self, prefix, response):
        self.score_requests.append((prefix, response))
        good = response[0] != 999
        values = {
            1: -1.0,
            2: (-0.2 if good else -1.4) if self.better_proposal else (-0.5 if good else -0.45),
            3: -0.4 if good else -1.2,
            4: -1.2 if good else -2.0,
        }
        return (values[prefix[0]],) * len(response)


def rows(recorder, name):
    return [json.loads(line) for line in (recorder.run_dir / name).read_text().splitlines()]


@pytest.mark.parametrize("outcomes", ["failures_only", "successes_only", "both"])
def test_minimal_loop_uses_available_rewards_and_refines_with_measured_changes(config, recorder, outcomes):
    benchmark = configure(config)
    backend = EditBackend(recorder, outcomes=outcomes)
    result = search(benchmark, backend, recorder, config)
    assert result.best_candidate["system_prompt"] == "refined"
    assert recorder.cost["task_calls"] == 2  # Train only: no validation or candidate rollouts.
    calls = rows(recorder, "optimizer_calls.jsonl")
    assert [r["phase"] for r in calls] == ["propose", "refine"]
    propose, refine = calls[0]["request"], calls[1]["request"]
    assert propose.startswith("Current prompt P:\nparent")
    assert "mean log-prob" not in propose
    assert "mean log-prob change =" in refine
    assert "sequence" not in propose + refine
    assert "Successful trajectory" in propose or "Failed trajectory" in propose
    assert "Current prompt P:\nparent" in refine
    assert "Candidate edit P':\nproposed" in refine
    expected_feedback = (
        "This edit moves the observed trajectories in the desired directions."
        if outcomes == "successes_only"
        else "This edit is undesirable because"
    )
    assert expected_feedback in refine
    assert "2+2" not in calls[0]["request"] and "3+3" not in calls[1]["request"]
    assert {ids for _, ids in backend.score_requests} <= {(2, 9), (999, 9)}
    edits = rows(recorder, "edits.jsonl")
    assert len(edits) == 2 and len({e["pool_sha256"] for e in edits}) == 1
    assert rows(recorder, "decisions.jsonl")[0]["accepted"]
    assert result.val_aggregate_scores == [None, None]


def test_keep_better_original_proposal_when_refinement_is_worse(config, recorder):
    benchmark = configure(config)
    result = search(benchmark, EditBackend(recorder, better_proposal=True), recorder, config)
    assert result.best_candidate["system_prompt"] == "proposed"
    assert rows(recorder, "decisions.jsonl")[0]["phase"] == "proposal"


def test_keep_parent_when_neither_edit_moves_all_responses_in_the_right_direction(config, recorder):
    benchmark = configure(config)
    result = search(benchmark, EditBackend(recorder, refinement="suppressed"), recorder, config)
    assert result.best_candidate["system_prompt"] == "parent"
    assert not rows(recorder, "decisions.jsonl")[0]["accepted"]


def test_new_step_generates_from_last_accepted_prompt_and_respects_task_budget(config, recorder):
    benchmark = configure(config)
    config["search"].update(max_iterations=3, max_task_rollouts=4)
    result = search(benchmark, EditBackend(recorder), recorder, config)
    captured = rows(recorder, "trajectories.jsonl")
    assert [r["prompt"] for r in captured] == ["parent", "parent", "refined", "refined"]
    assert recorder.cost["task_calls"] == result.total_metric_calls == 4
    assert len(rows(recorder, "optimizer_calls.jsonl")) == 4


@pytest.mark.parametrize("phase", ["propose", "refine"])
def test_incomplete_optimizer_text_is_preserved_and_never_adopted(config, recorder, phase):
    benchmark = configure(config)

    class TruncatedBackend(EditBackend):
        def generate(self, prompt, question, *, reflection=False):
            generated = super().generate(prompt, question, reflection=reflection)
            target = PROPOSER_SYSTEM if phase == "propose" else REFINER_SYSTEM
            return (
                replace(generated, finish_reason="length") if reflection and prompt == target else generated
            )

    with pytest.raises(ValueError, match="Incomplete"):
        search(benchmark, TruncatedBackend(recorder), recorder, config)
    assert rows(recorder, "optimizer_calls.jsonl")[-1]["error"]
    assert not (recorder.run_dir / "decisions.jsonl").exists()


@pytest.mark.parametrize(
    "rewards,deltas,verified",
    [
        ([0, 0], [-0.3, -0.1], True),
        ([1, 1], [0.3, 0.1], True),
        ([1, 0], [0.3, -0.1], True),
        ([1, 0], [0.3, 0.1], False),
        ([0, 0], [-0.3, 0.1], False),
        ([1, 1], [0.3, -0.1], False),
        ([0], [0.0], False),
        ([1], [0.0], False),
    ],
)
def test_each_trajectory_direction_is_verified(rewards, deltas, verified):
    refs = [
        Trajectory("q", "question", "train", i, "P", "text", (1,), (i + 2,), r, "eos")
        for i, r in enumerate(rewards)
    ]

    class Scorer:
        def score(self, prompt, t):
            return Likelihood((-2.0 + (deltas[t.repeat_index] if prompt != "P" else 0),))

    result = fixed_directional_gain("P", "C", refs, Scorer())
    assert result["verified"] == verified
    assert result["score"] == pytest.approx(
        sum((2 * r - 1) * d for r, d in zip(rewards, deltas, strict=True)) / len(refs)
    )


def test_question_weight_is_independent_of_response_count():
    refs = [Trajectory("a", "one", "train", i, "P", "text", (1,), (2,), 1, "eos") for i in range(3)]
    refs += [Trajectory("b", "two", "train", 0, "P", "text", (1,), (3,), 0, "eos")]

    class Scorer:
        def score(self, prompt, t):
            return Likelihood((-1 + ((0.2 if t.reward else -0.4) if prompt != "P" else 0),))

    result = fixed_directional_gain("P", "C", refs, Scorer())
    assert result["verified"] and result["score"] == pytest.approx(0.3)


def test_config_and_preview_have_no_search_components_beyond_the_minimal_loop(config):
    from prompt_policy.cli import run

    configure(config)
    validate_config(config)
    config["edit_refinement"]["run_ablations"] = True
    with pytest.raises(ValueError, match="must be empty"):
        validate_config(config)
    root = Path(__file__).parents[1]
    plan = run(root / "experiments/directional_edit_dapo_pilot/experiment.toml", dry_run=True)
    assert plan["final_selection"] == "last_verified_prompt"
    assert plan["edit_limits_per_outer_iteration"]["optimizer_calls"] == 2
    assert plan["edit_limits_per_outer_iteration"]["measured_candidates"] == 2


def test_cli_selects_last_verified_prompt_before_test_without_validation(tmp_path, monkeypatch):
    from prompt_policy import backends
    from prompt_policy.cli import run

    root = Path(__file__).parents[1]
    text = (root / "experiments/directional_edit_dapo_pilot/experiment.toml").read_text()
    model = tmp_path / "model"
    model.mkdir()
    import re

    text = re.sub(r"^name_or_path = .*$", f'name_or_path = "{model}"', text, flags=re.MULTILINE)
    text = re.sub(r"^initial_prompt = .*$", 'initial_prompt = "parent"', text, flags=re.MULTILINE)
    text = text.replace("max_iterations = 2", "max_iterations = 1")
    for split, question, answer in [("train", "1+1", "2"), ("validation", "2+2", "4"), ("test", "3+3", "6")]:
        path = tmp_path / f"{split}.jsonl"
        path.write_text(json.dumps({"id": split, "question": question, "answer": answer}) + "\n")
        text = re.sub(rf"^{split} = .*$", f'{split} = "{path}"', text, flags=re.MULTILINE)
    path = tmp_path / "experiment.toml"
    path.write_text(text)
    monkeypatch.setattr(backends, "LocalHFBackend", lambda config, recorder: EditBackend(recorder))
    output = run(path, output=tmp_path / "run")
    selected = json.loads((output / "selection.json").read_text())
    result = json.loads((output / "result.json").read_text())
    assert selected["criterion"] == "last_verified_prompt" and selected["prompt"] == "refined"
    assert result["validation_accuracy"] is None and result["search_cost"]["task_calls"] == 2
    assert all(
        json.loads(line)["split"] == "train"
        for line in (output / "trajectories.jsonl").read_text().splitlines()
    )
    assert json.loads((output / "manifest.json").read_text())["status"] == "complete"


def test_exported_prompts_are_exact_current_templates():
    root = Path(__file__).parents[1] / "examples/contrastive_edit"
    assert (root / "proposer_system.txt").read_text() == PROPOSER_SYSTEM
    assert (root / "refiner_system.txt").read_text() == REFINER_SYSTEM
    assert "likelihood" not in PROPOSER_SYSTEM
    assert "hypothesis" not in PROPOSER_SYSTEM + REFINER_SYSTEM


def test_refiner_gets_the_users_mean_likelihood_example_with_fixed_trajectory_contents():
    from prompt_policy.edit_prompts import request_payload

    refs = [
        Trajectory("q", "1+1", "train", i, "P", response, (1,), ids, r, "eos")
        for i, (response, ids, r) in enumerate(
            [
                ("Reasoning A. Answer: 2", (2, 2, 9), 1),
                ("Reasoning B. Answer: 3", (3, 9), 0),
            ]
        )
    ]

    class Scorer:
        def score(self, prompt, t):
            value = -0.42 if t.reward else -0.31
            if prompt != "P":
                value += 0.18 if t.reward else 0.24
            return Likelihood((value,) * len(t.response_ids))

    evaluation = fixed_directional_gain("P", "P2", refs, Scorer())
    rollouts = [
        {
            "example_id": "q",
            "question": t.question,
            "gold_answer": "2",
            "response": t.text,
            "reward": t.reward,
        }
        for t in refs
    ]
    request = request_payload("P", rollouts, "fixed rule", candidate="P2", evaluation=evaluation)
    assert "Successful trajectory 1:\nReasoning A. Answer: 2" in request
    assert "Failed trajectory 2:\nReasoning B. Answer: 3" in request
    assert "mean log-prob under P = -0.42" in request
    assert "mean log-prob under P = -0.31" in request
    assert "mean log-prob change = +0.18" in request
    assert "mean log-prob change = +0.24" in request
    assert "sequence" not in request
    assert "Measured direction verification: failed" in request
    assert "This edit is undesirable" in request
    assert "semantic component" in request and "failed trajectories less likely" in REFINER_SYSTEM
    assert not evaluation["verified"]  # Positive overall gain cannot excuse reinforcing the failure.


def test_refiner_single_class_feedback_never_invents_the_other_class(config, recorder):
    benchmark = configure(config)
    search(benchmark, EditBackend(recorder, outcomes="failures_only"), recorder, config)
    request = rows(recorder, "optimizer_calls.jsonl")[1]["request"]
    assert "Failed trajectory 1:" in request and "Failed trajectory 2:" in request
    assert "Successful trajectory" not in request
